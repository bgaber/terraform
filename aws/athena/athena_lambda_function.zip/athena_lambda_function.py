import boto3
import time
import os
from datetime import datetime, timedelta

# Fetch environment variables
AWS_REGION = os.environ["AWS_REGION"]
DATABASE_NAME = os.environ["DATABASE_NAME"]
TABLE_NAME = os.environ["TABLE_NAME"]
S3_OUTPUT = os.environ["S3_OUTPUT"]
SNS_TOPIC_ARN = os.environ["SNS_TOPIC_ARN"]
S3_BUCKET = os.environ["S3_BUCKET"]
S3_KEY = os.environ["S3_KEY"]

# Initialize clients
athena_client = boto3.client("athena", region_name=AWS_REGION)
s3_client = boto3.client("s3", region_name=AWS_REGION)
sns_client = boto3.client("sns", region_name=AWS_REGION)

def query_athena():
    """Run an Athena query to get the Approved status and Version for the latest version"""

    query = f"""
    SELECT Version, Approved
    FROM {DATABASE_NAME}.{TABLE_NAME}
    ORDER BY CAST(SPLIT(Version, '.')[1] AS INT) DESC,
             CAST(SPLIT(Version, '.')[2] AS INT) DESC
    LIMIT 1
    """

    # Start Athena query execution
    response = athena_client.start_query_execution(
        QueryString=query,
        QueryExecutionContext={"Database": DATABASE_NAME},
        ResultConfiguration={"OutputLocation": S3_OUTPUT}
    )

    query_execution_id = response["QueryExecutionId"]

    # Wait for query completion
    while True:
        status_response = athena_client.get_query_execution(QueryExecutionId=query_execution_id)
        status = status_response["QueryExecution"]["Status"]["State"]

        if status in ["SUCCEEDED", "FAILED", "CANCELLED"]:
            break
        time.sleep(1)

    if status != "SUCCEEDED":
        raise Exception(f"Athena query failed with status: {status}")

    # Retrieve query results
    results = athena_client.get_query_results(QueryExecutionId=query_execution_id)
    if "ResultSet" in results and "Rows" in results["ResultSet"]:
        rows = results["ResultSet"]["Rows"]
        if len(rows) > 1:
            version = rows[1]["Data"][0]["VarCharValue"]
            approved_status = rows[1]["Data"][1]["VarCharValue"]
            return version, approved_status

    return "Unknown", "No result found"

def check_file_age():
    try:
        response = s3_client.head_object(Bucket=S3_BUCKET, Key=S3_KEY)
        last_modified = response['LastModified']
        age = datetime.now(last_modified.tzinfo) - last_modified
        return age > timedelta(days=30)
    except:
        return True  # If file doesn't exist or there's an error, assume it's old

def send_sns_notification():
    message = "The {S3_KEY} file is more than 30 days old and needs to be updated."
    sns_client.publish(TopicArn=SNS_TOPIC_ARN, Message=message)

def lambda_handler(event, context):
    latest_version, approved_status = query_athena()
    
    # Check if it's the first day of the month
    if datetime.now().day == 1:
        if check_file_age():
            send_sns_notification()
    
    return {"message": f"The approval status of version {latest_version} is {approved_status}"}

